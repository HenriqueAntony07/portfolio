export const contactsData = {
    email: 'ishaqjaveed1@gmail.com',
    phone: '+923217281104',
    address: 'Sahiwal, Punjab, Pakistan',
    github: 'https://github.com/javeedishaq',
    facebook: 'https://web.facebook.com/javeedishaq',
    linkedIn: 'https://www.linkedin.com/in/javeed-ishaq/',
    twitter: 'https://twitter.com/javeedishaq',
    stackOverflow: 'https://stackoverflow.com/users/4778545/javeed-ishaq',
    devUsername: "javeedishaq"
}