export interface ProjectCard {
    name: string;
    tools: string[];
    role: string;
    description: string;
}