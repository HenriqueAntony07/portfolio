export interface Education {
    id: number;
    duration: string;
    title: string;
    institution: string;
}