export interface ContactForm {
    name: string;
    email: string;
    message: string;
}